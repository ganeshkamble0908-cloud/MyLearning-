package myfirstproject;

public class UnaryOperators1 {

	public static void main(String[] args) {
		int a = 5; //Local Variable
		
		System.out.println(a);//5
		System.out.println(a++); //It will print '5' and saved valued in RAM '6'
		System.out.println(a);//6
		System.out.println(a++);//It will print '6' and saved valued in RAM '7'
		System.out.println(++a); //8
		System.out.println(a--); //It will print '8' and saved valued in RAM '7'
		System.out.println(a); //7
		System.out.println(--a); //It will print '6' and saved valued in RAM '6'
		
	}
}
