package myfirstproject;

public class Loop3 {

	public static void main(String[] args) {
		
		int i = 10; //Local Variable
		
		while(i < 15 & i < 12 ) {
			System.out.println(i);
			i++;
		}
		System.out.println("Condition Flase, control came out from Loop");

	}

}
