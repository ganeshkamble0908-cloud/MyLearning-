package myfirstproject;

public class IfElse1 {

	public static void main(String[] args) {
		
		int a = 15; //Local Variable
		
		if(a > 10) {
			
		System.out.println("a is grater than 10");
		
		}

	}

}
