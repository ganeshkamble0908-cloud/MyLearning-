package myfirstproject;

public interface Interface4 {

	//abstract method
	void b();
}
