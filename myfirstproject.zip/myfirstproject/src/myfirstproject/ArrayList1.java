package myfirstproject;

import java.util.ArrayList;

public class ArrayList1 {

	public static void main(String[] args) {
	
		//Creating ArayList
		ArrayList<Object> obj = new ArrayList<Object>();
		
		//Adding object in ArrayList
		obj.add(1);
		obj.add("Selenium");
		obj.add(7.0);
		obj.add('a');
		obj.add(3 > 12);
		
		//Print ArrayList Element - 1st Way
		System.out.println(obj);
		
		//Print ArrayList Element using for each loop
		for (Object bcd:obj) {
			System.out.println("For each Loop:" + bcd);
		}
		
	}

}
