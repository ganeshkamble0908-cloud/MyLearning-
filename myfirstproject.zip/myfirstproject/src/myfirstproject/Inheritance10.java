package myfirstproject;

public class Inheritance10 extends Inheritance9 {
	
	public void cook() {
		System.out.println("I am cooking");
	}
	
	public static void main(String[] args) {
		Inheritance10 i10 = new Inheritance10();
		i10.play();
		i10.watching();
		i10.cook();
	}
}
