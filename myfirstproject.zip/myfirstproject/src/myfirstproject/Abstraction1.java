package myfirstproject;


public abstract class Abstraction1 {

	static int a = 5; // static variable
	int b = 5; // Global Variable
	final int c = 5; // final variable

	// abstract method
	public abstract void eat();

	// non abstract method
	public void a() {
		System.out.println("Non Abstract Method");
	}

}
