package myfirstproject;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Alert1 {

	public static void main(String[] args) throws Exception {
		// Setting the property of chrome driver and passing chromedriver path
				System.setProperty("webdriver.chrome.driver", "D:\\Java Projects\\chromedriver.exe");
				WebDriver driver = new ChromeDriver();
				driver.manage().window().maximize();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				driver.get("https://demoqa.com/alerts");
				
				//Accept alerts - using JavaScriptExecutor
				Thread.sleep(2000);
				JavascriptExecutor jse = (JavascriptExecutor) driver;
				jse.executeScript("document.getElementById('confirmButton').click()");
				Thread.sleep(2000);
				System.out.println(driver.switchTo().alert().getText());
				driver.switchTo().alert().accept();
				System.out.println("Alert accepted");
				
				//Dismiss alerts - using JavaScriptExecutor
				Thread.sleep(2000);
				jse.executeScript("document.getElementById('confirmButton').click()");
				Thread.sleep(2000);
				driver.switchTo().alert().dismiss();
				System.out.println("Alert dismissed");
				

	}

}
