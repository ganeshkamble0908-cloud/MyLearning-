package myfirstproject;

public class Encapsulation1 {

	String name; //Global Variable
	int b;
	final int c = 2;
	
	public void a() {
		//c = 2; // final variable can not change the value
	}
	
	//final method
	final void b() {
		System.out.println("final method");
	}
	
	public void setName(String s) {
		this.name = s;
		this.b = 5;
		System.out.println(b);
		System.out.println(c);
	}
	
	public Object getName() {
		return name;
	} 
}
