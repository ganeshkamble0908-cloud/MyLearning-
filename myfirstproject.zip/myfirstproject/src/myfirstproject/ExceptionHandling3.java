package myfirstproject;

public class ExceptionHandling3 {

	public static void main(String[] args) {
		
		String s = "Selenium";
		
		try {
			int i = Integer.parseInt(s);
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Exception Handled");

	}

}
