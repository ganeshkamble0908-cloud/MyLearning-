package myfirstproject;

public class Variable9 {

	public static void main(String[] args) {
		int a;//Declaration of variable
		a = 10;//Assigning value to 'a' variable
		System.out.println(a);//10 -calling a variable
		
		char b = 'h';
		System.out.println(b);//h
		
		String c = "a";
		System.out.println(c);//a
		
		String str = "Hello Ganesh";
		System.out.println(str.length());//12
		System.out.println(str);//Hello Ganesh

	}

}
