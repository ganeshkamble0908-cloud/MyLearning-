package myfirstproject;

public class Variable1 {

	public static void main(String[] args) {
		int a=5;     //int type of local variable
		System.out.println(a);//5 calling local variable
		
		
		int x=200;
		System.out.println(x);//200
		
		x=300;
		System.out.println(x);//300
		
		x=400;
		System.out.println(x);//400
		
		char c='a'; //char type of local variable, should be placed inside single quote
		System.out.println(c);//a
		
		boolean b = true;
		System.out.println(b);//true
		b=false;
		System.out.println(b);//false
		
		System.out.println(3>12); //false
		
		int e = 5;
		int f = 50;
		
		boolean z = e>f;
		System.out.println(z);//false
		
	}

}
