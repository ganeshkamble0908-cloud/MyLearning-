package myfirstproject;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class DropDown {

	public static void main(String[] args) throws Exception {
		// Setting the property of chrome driver and passing chromedriver path
				System.setProperty("webdriver.chrome.driver", "D:\\Java Projects\\chromedriver.exe");
				WebDriver driver = new ChromeDriver();
				driver.manage().window().maximize();
				driver.get("https://facebook.com");
				driver.findElement(By.xpath("//a[text()='Create new account']")).click();
				Thread.sleep(2000);
				
				//1st Way
				List<WebElement> birthmonth = driver.findElements(By.xpath("//select[@id='month']/option"));
				System.out.println("Total Dropdwon Values" + birthmonth.size());
				birthmonth.get(3).click(); //Apr
				Thread.sleep(2000);
				birthmonth.get(8); //Sep

				//2nd Way
				WebElement  bm = driver.findElement(By.xpath("//select[@id='month']"));
				Select month = new Select(bm);
				Thread.sleep(2000);
				month.selectByVisibleText("Apr");
				Thread.sleep(2000);
				month.selectByValue("12");
				Thread.sleep(2000);
				month.selectByIndex(7);
				System.out.println(month.getFirstSelectedOption().getText()); //Aug-Current Selected Value
				
				//3rd Way
				List<WebElement> dropdown = month.getOptions();
				System.out.println("Total Dropdown Values 2nd Time" + dropdown.size());
				for(int i = 0; i < dropdown.size(); i++) {
					if(dropdown.get(i).getText().equalsIgnoreCase("Sep")) {
						dropdown.get(i).click();
					}
				}
				
				//4th Way
				Thread.sleep(2000);
				WebElement  bm1 = driver.findElement(By.xpath("//select[@id='month']"));
				bm1.sendKeys("Jun");
				
				//5th Way
				Thread.sleep(2000);
				driver.findElement(By.xpath("//select[@id='month']")).sendKeys("Mar");
				
				driver.quit();
				
	}

}
