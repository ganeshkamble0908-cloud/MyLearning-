package myfirstproject;

public class Variable8 {

	
		int b = 10;//Global variable
		static int c = 5;//static variable
	
		//static method
		public static void d() {
			int e = 15;  //Local variable
			System.out.println(e);
		}
		//Non Static method
		public void f() {
			int g =5; //Local variable
			System.out.println(g);
		}
		public static void main(String[] args) {
			int a = 6; //Local variable
			System.out.println(a);  //6 calling a variable
			//Static member calling
			System.out.println(c);
			d();
			
			//Non Static method calling
			Variable8 v8 = new Variable8();
			System.out.println(v8.b); //Calling non static variable using class ref.
			v8.f(); // calling non static method using class ref.
			
		}

}
