package myfirstproject;

public class Inheritance3 {
	
	int z;//Global Variable
	
	public void add(int x, int y) {
		z = x + y;
		System.out.println(z);
	}
	
	public void substract(int x, int y) {
		z = x - y;
		System.out.println(z);
		
	}
}
