package myfirstproject;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class MouseSimulation1 {

	public static void main(String[] args) throws Exception {
		
		// Setting the property of chrome driver and passing chrome driver path
				System.setProperty("webdriver.chrome.driver", "D:\\Java Projects\\chromedriver.exe");
				WebDriver driver = new ChromeDriver();
				driver.manage().window().maximize();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				driver.get("https://www.flipkart.com/mobile-phones-store?fm=neo%2Fmerchandising&iid=M_73916afc-f3ec-467e-864a-203d44a7e7c5_1_372UD5BXDFYS_MC.ZRQ4DKH28K8J&otracker=hp_rich_navigation_2_1.navigationCard.RICH_NAVIGATION_Mobiles_ZRQ4DKH28K8J&otracker1=hp_rich_navigation_PINNED_neo%2Fmerchandising_NA_NAV_EXPANDABLE_navigationCard_cc_2_L0_view-all&cid=ZRQ4DKH28K8J");
				
				//Create Electronic Web Element Ref.
				WebElement electro = driver.findElement(By.xpath("//*[text()='Electronics']")); 
				//Mouse Simulation using Action class 
				Actions act  = new Actions(driver);
				//Mouse over to Electronics
				Thread.sleep(2000);
				act.moveToElement(electro).build().perform();
				Thread.sleep(2000);
				driver.findElement(By.xpath("//*[text()='Realme']")).click();
				
				
				//Keyboard operation
				Thread.sleep(2000);
				WebElement men = driver.findElement(By.xpath("//*[text()='Men']"));
				act.sendKeys(men, Keys.ENTER).build().perform();
				System.out.println("Men Option Clicked");
				
				//Right click on Web Page
				Thread.sleep(2000);
				act.contextClick(electro).build().perform();
	}

}
