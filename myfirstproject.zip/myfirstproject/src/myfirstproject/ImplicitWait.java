package myfirstproject;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ImplicitWait {

	public static void main(String[] args) {
		// Setting the property of chrome driver and passing chromedriver path
		System.setProperty("webdriver.chrome.driver", "D:\\Java Projects\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.google.com");

		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS); //Implicit Wait
		driver.findElement(By.xpath("//textarea[@name='q']")).sendKeys("How stuff work");
		
		
		//Handling Auto suggestions
		List<WebElement> allsuggestions = driver.findElements(By.xpath("//ul[@role='listbox']/li"));
		System.out.println("Total Element Found" + allsuggestions.size());
		
		for (int i = 0; i < allsuggestions.size(); i++) {
			String exResult = "how stuff works science";
			if(allsuggestions.get(i).getText().equalsIgnoreCase(exResult)) {
				allsuggestions.get(i).click();
				break;
			}
		}
		
	}

}
