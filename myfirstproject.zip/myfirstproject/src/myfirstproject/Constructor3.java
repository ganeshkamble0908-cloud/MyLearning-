package myfirstproject;

public class Constructor3 {
	
	//Constructor Overloading
	Constructor3(){
		System.out.println("No Parameter");
	}
	
	Constructor3(int s){
		System.out.println("int parameter");
	}
	
	Constructor3(String s){
		System.out.println("String parameter");
	}
	
	public static void main(String[] args) {
		Constructor3 c3 = new Constructor3();
		Constructor3 c4 = new Constructor3(1);
		Constructor3 c5 = new Constructor3("Selenium");
		
	}
	
	
	
}
