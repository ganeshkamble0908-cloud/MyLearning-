package myfirstproject;

public class FirstClass {
	int a=10;         //Global variable
	static int b=5;   //static variable
	public static void main(String[] args) {
		
System.out.println("Hello Aarya Ganesh Kamble");
System.out.println("Hello Sima Ganesh Kamble");
System.out.println("Hello Ganesh Laxman Kamble");
int c=2;
System.out.println(c);
ganesh();
seema();
	}
public static void ganesh() {
	System.out.println("Aarya");
}
public static void seema() {
	System.out.println("Seema");
}
}
