package myfirstproject;

public class Inheritance1 {

	public void roll() {
		int roll = 5;	
		System.out.println(roll);
		
	
}
}