package myfirstproject;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class JavaScript1 {

	public static void main(String[] args) throws Exception {
		// Setting the property of chrome driver and passing chrome driver path
		System.setProperty("webdriver.chrome.driver", "D:\\Java Projects\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get("https://www.facebook.com");
		
		//Delete all cookies
		Thread.sleep(2000);
		
		//JavaScriptExecutor
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		
		
		//Locate Web Element using JavascriptExecutor
		jse.executeScript("document.getElementById('email').value='abc@gmail.com'");
		Thread.sleep(2000);
		jse.executeScript("document.getElementById('password')[0].value='abc12345'"); // Not working
		Thread.sleep(2000);
		jse.executeScript("document.getElementByName('login')[0].click()");// Not working
		
		//Scroll Down using javaScript
		Thread.sleep(2000);
		jse.executeScript("window.scrollBy(0, 500)");// Not working
		
		//Scroll Up using javaScript
				Thread.sleep(2000);
				jse.executeScript("window.scrollBy(0, -500)");// Not working
	}

}
