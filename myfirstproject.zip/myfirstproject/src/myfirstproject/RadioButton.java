package myfirstproject;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class RadioButton {

	public static void main(String[] args) throws Exception {
		// Setting the property of chrome driver and passing chromedriver path
		System.setProperty("webdriver.chrome.driver", "D:\\Java Projects\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://facebook.com");
		
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[text()='Create new account']")).click();
		
		//1st way
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@value='1']")).click();//Female
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@value='2']")).click();//Male
		Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@value='-1']")).click();//Custom
		
		//2nd Way
		List<WebElement> radios = driver.findElements(By.xpath("//input[@type='radio']"));
		System.out.println("Total radio buttons" + radios.size());
		System.out.println(radios.get(0).isSelected()); //False
		System.out.println(radios.get(0).isEnabled()); //true
		System.out.println(radios.get(0).isDisplayed()); //true
		
		Thread.sleep(2000);
		radios.get(1); //Male
		System.out.println(radios.get(1).isSelected()); //false
		
		
		//3rd Way
		List<WebElement> radiosText = driver.findElements(By.xpath("//*[@class='_58mt']"));
		System.out.println("Total Radio Buttons Text" + radiosText.size());
		String expectResult = "Female";
		for(int i = 0; i < radiosText.size(); i++) {
			if(radiosText.get(i).getText().equalsIgnoreCase(expectResult)) {
				radiosText.get(i).click();
				System.out.println(expectResult + "" + "clicked");
			}
		}
		
		driver.close();
		
		
		

	}

}
