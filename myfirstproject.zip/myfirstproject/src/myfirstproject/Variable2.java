package myfirstproject;

public class Variable2 {

	public static void main(String[] args) {
		String s = "Hello Aarya Ganesh Kamble";//String type local variable
		
		//Print the length of string parameter
		System.out.println(s);//calling variable
		System.out.println(s.length());//calling a method using class reference
		
	}

}
