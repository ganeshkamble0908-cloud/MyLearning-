package myfirstproject;

public interface Interface3 {

	//abstract method
	void a();
	
}
