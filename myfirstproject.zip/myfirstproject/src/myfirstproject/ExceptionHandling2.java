package myfirstproject;

public class ExceptionHandling2 {

	public static void main(String[] args) {
		String s = null;

		try {
			System.out.println(s.length());
		} catch (Exception e) {

			e.printStackTrace();// Short key for try catch block use right click of mouse and click on surround with option
		}

		System.out.println("Exception Handled");

	}

}
