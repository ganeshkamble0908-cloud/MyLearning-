package myfirstproject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class OpenBrowser {

	public static void main(String[] args) throws Exception {
		
		//Setting the property of chrome driver and passing chromedriver path
		System.setProperty("webdriver.chrome.driver", "D:\\Java Projects\\chromedriver.exe");
		
		//Launching chrome browser instance
		WebDriver driver = new ChromeDriver();
		
		//Maximize the window
		Thread.sleep(2000);
		 driver.manage().window().maximize();
		 
		 //Open url using get() method
		 Thread.sleep(2000);
		 driver.get("https://facebook.com");
		 
		 //Delete all cookies
		 Thread.sleep(2000);
		 driver.manage().deleteAllCookies();
		 
		 //Open url using navigate() method
		 Thread.sleep(2000);
		 driver.navigate().to("https://www.google.com");
		 
		 //Refresh the page
		 Thread.sleep(2000);
		 driver.navigate().refresh();
		 
		 //Navigate to back
		 Thread.sleep(2000);
		 driver.navigate().back();
		 
		 //Navigate to forward
		 Thread.sleep(2000);
		 driver.navigate().forward();
		 
		 //Fetch current url
		 Thread.sleep(2000);
		 System.err.println(driver.getCurrentUrl());
		 
		//Fetch title of the web page
		 Thread.sleep(2000);
		 System.err.println(driver.getTitle());
		 
		 //close the browser instance
		 Thread.sleep(2000);
		 driver.close();
		 
		 
		 
		 
		 
		

	}

}
