package myfirstproject;

public class Loop2 {

	public static void main(String[] args) {
		
		//Defining an Object Array
		Object a[] = {"Selenium", 10.5, 3 > 12, 'c', 5};
		
		//Print an array using for each loop
		for(Object b : a) {
			System.out.println(b);
		}

	}

}
