package myfirstproject;

public class Variable6 {

	public static void main(String[] args) {
		int a; //Declaring the local variable
		int b = 5; //Defining local variable
		System.out.println(b);
		//Defining c & d variable
		int c = 6;
		int d = 7;
		
		System.out.println(c);
		System.out.println(d);

	}

}
