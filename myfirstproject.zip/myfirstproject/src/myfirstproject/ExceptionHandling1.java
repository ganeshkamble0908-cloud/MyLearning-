package myfirstproject;

public class ExceptionHandling1 {

	// Exception Handling

	public static void main(String[] args) {

		try {

			int a = 5 / 0;

		} catch (ArithmeticException a) {
			a.printStackTrace(); // Print complete exception info
			System.out.println(a);
		} catch (NullPointerException n) {
			System.out.println(n);
		} catch (ArrayIndexOutOfBoundsException s) {
			System.out.println(s);
		}catch(Exception b) {
			System.out.println("Exception Handled");
		}

		System.out.println("Hello Ganesh Kamble");

	}

}
