package myfirstproject;

public class Inheritance8 {
	public void play() {
		System.out.println("I am playing");
	}
}
