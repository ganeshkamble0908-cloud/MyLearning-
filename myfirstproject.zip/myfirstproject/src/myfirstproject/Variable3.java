package myfirstproject;

public class Variable3 {
	
	int data = 50; //Global variable
	static int f = 5; //static variable 
	
	//pre defined method
	public static void main(String[] args) {
		int n =5; //Local variable
		System.out.println(n);
		
	}
	static int k = 7; //static variable
	
	//User Defined method
	public void a() {
		int a = 100; //Local variable
		System.out.println(a);
	}

}
