package myfirstproject;

public interface Interface1 {
	
	//abstract method
	public abstract void a();
	
	//abstract method
	public abstract void b();
}
