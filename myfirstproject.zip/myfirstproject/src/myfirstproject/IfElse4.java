package myfirstproject;

public class IfElse4 {

	public static void main(String[] args) {
		
		int age = 15; //Local Variable
		int weight = 55; //Local Variable
		
		//Outer if statement
		if(age > 18) {
			
			//Inner if statement
			if(weight > 50) {
				System.out.println("Eligible");
				}else {
					System.out.println("Not Eligible");
				}
			} else {
				System.out.println("Age is not grater than 18");
			}
	}

}
