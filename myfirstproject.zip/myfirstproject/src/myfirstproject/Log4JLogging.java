package myfirstproject;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class Log4JLogging {

	public static void main(String[] args) {
		
		//Create Logger Instance
		Logger logger = Logger.getLogger("Log4JLogging");
		
		//Configure log4j.properies file
		PropertyConfigurator.configure("D:\\Java Projects\\myfirstproject\\Repository");

	}

}
