package myfirstproject;

public class ExceptionHandling7 {
	
	public static void a(int age) {
	try {
		if (age < 18) {
			throw new ArithmeticException("Age is less than 18, So not eligible");
		} else {
			System.out.println("Eligible");
		}
	} catch (Exception e) {
		
		e.printStackTrace();
	}
	
	}
	public static void main(String[] args) {
		a(15);
		a(18);
	}
}


