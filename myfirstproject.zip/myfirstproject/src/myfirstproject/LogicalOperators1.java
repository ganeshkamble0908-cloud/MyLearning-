package myfirstproject;

public class LogicalOperators1 {

	public static void main(String[] args) {
		int a = 10;//Local Variable
		int b = 5;//Local Variable
		int c = 20;//Local Variable
		
		//Logical Operators- If 1st condition false, 2nd condition will not check
		System.out.println(a < b && a < c );//false
		System.out.println(a);
		
		//Bitwise operators - if 1st condition false, 2nd condition will also check
		
		System.out.println(a < b & a++ < c);//false
		System.out.println(a);
	}
}
