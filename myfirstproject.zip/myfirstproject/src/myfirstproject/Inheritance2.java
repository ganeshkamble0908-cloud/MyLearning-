package myfirstproject;

public class Inheritance2  extends Inheritance1{

	public void number() {
		System.out.println("Hi Selenium");
	}
	
	public static void main(String[] args) {
		
		Inheritance2 in2 = new Inheritance2();
		in2.number();
		in2.roll();

	}
}
