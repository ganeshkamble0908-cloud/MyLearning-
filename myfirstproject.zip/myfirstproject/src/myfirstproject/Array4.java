package myfirstproject;

public class Array4 {

	public static void main(String[] args) {
		// Defining Multi Dimensional Array
		int a[][] = { { 1, 2, 3, 4, 5 }, { 5, 6, 7, 8 }, { 9, 10, 11, 12 } };

		// Total number of rows
		int row = a.length; // Length is the property of an array
		System.out.println(row); // 3

		// Total Number of column
		int column = a[0].length;
		System.out.println(column); // 4

		// Print all values - matrix from
		// Outer Loop
		for (int i = 0; i < row; i++) {

			// Inner Loop
			for (int j = 0; j < column; j++) {

				System.out.println(a[i][j] + "  ");
			}
		}

		System.out.println();

	}

}
