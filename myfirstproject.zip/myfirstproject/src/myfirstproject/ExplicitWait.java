package myfirstproject;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ExplicitWait {

	public static void main(String[] args) throws Exception {
		// Setting the property of chrome driver and passing chromedriver path
		System.setProperty("webdriver.chrome.driver", "D:\\Java Projects\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get("https://facebook.com");

		// Enter UserName
		driver.findElement(By.id("email")).sendKeys("abcgmail.com");

		// Fetch input box attribute value
		System.out.println(driver.findElement(By.id("email")).getAttribute("value"));

		// Use Explicit wait
		WebDriverWait wt = new WebDriverWait(driver, 60);
		wt.until(ExpectedConditions.elementToBeClickable(By.id("pass"))).sendKeys("abcd");
		Thread.sleep(2000);
		driver.close();
	}

}
