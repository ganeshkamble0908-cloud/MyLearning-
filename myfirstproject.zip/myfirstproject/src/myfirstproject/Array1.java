package myfirstproject;

public class Array1 {

	public static void main(String[] args) {
		
		//Declaring an array
		int a[] = new int[5];
		
		//Print the length of array
		System.out.println(a.length);
		
		//Print default value of an integer array
		for (int i = 0; i < a.length; i++) {
			System.out.println(a[i]);
		}
		
		//Assign value to an array
		a[0] = 65;
		a[1] = 95;
		a[2] = 5;
		a[3] = 10;
		a[4] = 6;
	
		  //	a[5] = 85; //java.lang.ArrayIndexOutofBoundsException
		
		System.out.println(a[3]); //10
		
		//Print all array element
		for (int i = 0; i < a.length; i++) {
			System.out.println(a[i]);
		}
		
		
	}

}
