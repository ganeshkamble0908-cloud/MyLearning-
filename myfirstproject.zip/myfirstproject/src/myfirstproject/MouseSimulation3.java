package myfirstproject;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class MouseSimulation3 {

	public static void main(String[] args) throws Exception {
		// Setting the property of chrome driver and passing chrome driver path
		System.setProperty("webdriver.chrome.driver", "D:\\Java Projects\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get("https://jqueryui.com/droppable/");
		
		//Switching to frame 
		driver.switchTo().frame(0);
		
		//Draggable Web Element
		WebElement drag = driver.findElement(By.id("draggable"));
		
		//Drag and using Actions class
		Thread.sleep(2000);
		Actions act = new Actions(driver);
		act.dragAndDropBy(drag, 150, 80).build().perform();

	}

}
