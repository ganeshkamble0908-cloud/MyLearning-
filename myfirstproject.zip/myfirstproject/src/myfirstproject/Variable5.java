package myfirstproject;

public class Variable5 {
public static void main(String[] args) {
	
	int x = 100; //Defining local variable
	
	//Calling x variable to printing values
	System.out.println(x);
	
	int y;//Declaring a variable
	y = x; //Calling x variable for initializing y
	System.out.println(y);//100
}
}
