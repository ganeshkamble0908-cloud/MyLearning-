package myfirstproject;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Frame {

	public static void main(String[] args) {
		// Setting the property of chrome driver and passing chromedriver path
		System.setProperty("webdriver.chrome.driver", "D:\\Java Projects\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get("https://paytm.com");
		
		//find the total numbers of frame s present on web page
		int allframes = driver.findElements(By.tagName("iframe")).size();
		System.out.println("Total Frames: " + allframes);
		
		//check if the element is present or not
		for(int i = 0; i < allframes; i++) {
			driver.switchTo().frame(i);
			driver.switchTo().frame(i);
			
			String expText = "Open Paytm App";
			String actText = driver.findElement(By.xpath("//*[text()='Open Paytm App']")).getText();
			
			if(actText.equalsIgnoreCase(expText)) {
				System.out.println("Element Found");
				break;
			}else {
				System.out.println("Element Not Found");
			}
		}

	}

}
