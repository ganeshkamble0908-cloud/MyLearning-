package myfirstproject;

public class Inheritance9 extends Inheritance8 {

	public void watching() {
		System.out.println("I am watching movie");
	}
}
